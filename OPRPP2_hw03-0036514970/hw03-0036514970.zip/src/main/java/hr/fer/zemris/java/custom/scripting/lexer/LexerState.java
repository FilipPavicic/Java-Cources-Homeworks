package hr.fer.zemris.java.custom.scripting.lexer;

public enum LexerState {
	TAG,TEXT

}
