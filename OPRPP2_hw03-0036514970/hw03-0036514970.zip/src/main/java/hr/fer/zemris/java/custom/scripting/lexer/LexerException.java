package hr.fer.zemris.java.custom.scripting.lexer;

public class LexerException extends RuntimeException {
	
	public LexerException(String message) {
        super(message);
    }
}
