package hr.fer.zemris.java.custom.scripting.lexer;

public enum TokenType {
	EOF,FUNCION, VARIABLE, NUMBER, OPERATORS, TAG_NAME, TEXT, SPACE, STRING, UNDERSCORE
}
