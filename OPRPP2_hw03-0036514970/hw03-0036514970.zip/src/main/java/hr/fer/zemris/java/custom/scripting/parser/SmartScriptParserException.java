package hr.fer.zemris.java.custom.scripting.parser;

public class SmartScriptParserException extends RuntimeException {
	
	public SmartScriptParserException(String message) {
        super(message);
    }
}
